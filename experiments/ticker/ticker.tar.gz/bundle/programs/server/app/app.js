var require = meteorInstall({"lib":{"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// lib/collections.js                                                                                     //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
Matches = new Meteor.Collection("matches");                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["cheerio","request",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/main.js                                                                                         //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
var _cheerio = require("cheerio");                                                                        // 1
                                                                                                          //
var _cheerio2 = _interopRequireDefault(_cheerio);                                                         //
                                                                                                          //
var _request = require("request");                                                                        // 2
                                                                                                          //
var _request2 = _interopRequireDefault(_request);                                                         //
                                                                                                          //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }         //
                                                                                                          //
function parse() {                                                                                        // 4
	var options = {                                                                                          // 5
		url: 'http://ru.dotabuff.com/players/92413647',                                                         // 6
		headers: {                                                                                              // 7
			"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36"
		}                                                                                                       //
	};                                                                                                       //
                                                                                                          //
	(0, _request2["default"])(options, Meteor.bindEnvironment(function (err, resp, body) {                   // 12
		$ = _cheerio2["default"].load(body);                                                                    // 13
		var rows = $("div.r-table div.r-row[data-link-to*='/matches/']"); // TODO: create a normal css selector
                                                                                                          //
		rows.each(function (i, e) {                                                                             // 12
			var match = $(e).attr("data-link-to").split('/')[2];                                                   // 17
			var hero = $(e).find("a:nth-child(2)").text();                                                         // 18
			var stat = $(e).find("a:nth-child(1)").text();                                                         // 19
			var time = $(e).find("time").attr("datetime");                                                         // 20
                                                                                                          //
			Matches.upsert({ match: match }, { $setOnInsert: {                                                     // 22
					match: match,                                                                                        // 23
					hero: hero,                                                                                          // 24
					stat: stat,                                                                                          // 25
					time: time                                                                                           // 26
				} });                                                                                                 //
		});                                                                                                     //
	}));                                                                                                     //
}                                                                                                         //
                                                                                                          //
Meteor.methods({                                                                                          // 32
	"parse": parse                                                                                           // 33
});                                                                                                       //
                                                                                                          //
Meteor.startup(function () {                                                                              // 36
	parse();                                                                                                 // 37
	setInterval(Meteor.bindEnvironment(parse), 1000 * 60);                                                   // 38
                                                                                                          //
	Meteor.publish("matches", function () {                                                                  // 40
		return Matches.find({});                                                                                // 41
	});                                                                                                      //
});                                                                                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
