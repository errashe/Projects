var require = meteorInstall({"lib":{"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// lib/collections.js                                                                                     //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
Matches = new Meteor.Collection("matches");                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["cheerio","request",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/main.js                                                                                         //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
var _cheerio = require("cheerio");                                                                        // 1
                                                                                                          //
var _cheerio2 = _interopRequireDefault(_cheerio);                                                         //
                                                                                                          //
var _request = require("request");                                                                        // 2
                                                                                                          //
var _request2 = _interopRequireDefault(_request);                                                         //
                                                                                                          //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }         //
                                                                                                          //
function parse(url) {                                                                                     // 4
	var options = {                                                                                          // 5
		url: url,                                                                                               // 6
		headers: {                                                                                              // 7
			"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36"
		}                                                                                                       //
	};                                                                                                       //
                                                                                                          //
	(0, _request2["default"])(options, Meteor.bindEnvironment(function (err, resp, body) {                   // 12
		$ = _cheerio2["default"].load(body);                                                                    // 13
		var user = $("div.header-content-title h1");                                                            // 14
		user = user.clone().children().remove().end().text();                                                   // 15
		var rows = $("div.r-table div.r-row[data-link-to*='/matches/']"); // TODO: create a normal css selector
                                                                                                          //
		rows.each(function (i, e) {                                                                             // 12
			var match = $(e).attr("data-link-to").split('/')[2];                                                   // 19
			var hero = $(e).find("a:nth-child(2)").text();                                                         // 20
			var stat = $(e).find("a:nth-child(1)").text();                                                         // 21
			var time = $(e).find("time").attr("datetime");                                                         // 22
                                                                                                          //
			Matches.upsert({ match: match, user: user }, { $setOnInsert: {                                         // 24
					user: user,                                                                                          // 25
					match: match,                                                                                        // 26
					hero: hero,                                                                                          // 27
					stat: stat,                                                                                          // 28
					time: time                                                                                           // 29
				} });                                                                                                 //
		});                                                                                                     //
	}));                                                                                                     //
}                                                                                                         //
                                                                                                          //
var list = ["http://ru.dotabuff.com/players/87094975", "http://ru.dotabuff.com/players/92413647", "http://ru.dotabuff.com/players/36981197", "http://ru.dotabuff.com/players/23509620", "http://ru.dotabuff.com/players/107020823", "http://ru.dotabuff.com/players/130181018"];
                                                                                                          //
function parseAll() {                                                                                     // 44
	for (var i in meteorBabelHelpers.sanitizeForInObject(list)) {                                            // 45
		Meteor.bindEnvironment(parse(list[i]));                                                                 // 46
	}                                                                                                        //
}                                                                                                         //
                                                                                                          //
function publish() {                                                                                      // 50
	Meteor.publish("matches", function () {                                                                  // 51
		return Matches.find({}, { limit: 20, sort: { time: -1 } });                                             // 52
	});                                                                                                      //
}                                                                                                         //
                                                                                                          //
Meteor.startup(function () {                                                                              // 56
	setInterval(Meteor.bindEnvironment(parseAll), 10 * 1000);                                                // 57
	publish();                                                                                               // 58
});                                                                                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
